<div class=wrap>
  <h2><?php echo SK_PLUGIN_NAME; ?></h2>
  <p><?php _e('This will Plugin will automatically add the users to The Sugar 
  CRM at time of the registration.') ?></p>
</div>    
